
using namespace std;
#include <string>
#ifndef Tiempo_h
#define Tiempo_h

class Tiempo{
  public:

    Tiempo();
    Tiempo(string hSal, string mSal);
    void setHoraSal(string hSal);
    void setMinutoSal(string mSal);
    string getHoraSal();
    string getMinutoSal();

  private:
    string horaSal;
    string minutoSal;
 
};

Tiempo::Tiempo(){
  horaSal= "-";
  minutoSal= "-";
}

Tiempo::Tiempo(string hSal, string mSal){
  horaSal= hSal;
  minutoSal= mSal;
}

void Tiempo::setHoraSal(string hSal){
  horaSal=hSal;
}

void Tiempo::setMinutoSal(string mSal){
  minutoSal=mSal;
}

string Tiempo::getHoraSal(){
  return horaSal;
}

string Tiempo::getMinutoSal(){
  return minutoSal;
}


#endif