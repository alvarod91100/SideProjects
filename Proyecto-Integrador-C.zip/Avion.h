using namespace std;
#ifndef Avion_h
#define Avion_h
#include <string>

class Avion{
  public:
    Avion();
    Avion(string aerol, int idAv);

    void setAerolinea(string aerol);
    void setIdAvion(int idAv);
    int getIdAvion();
    string getAerolinea();

  private:
    string aerolinea;
    int idAvion;

};


Avion::Avion(){
  aerolinea="-";
  idAvion= 000;
}

Avion::Avion(string aerol, int idAv){
  aerolinea=aerol;
  idAvion=idAv;
}

void Avion::setAerolinea(string aerol){
  aerolinea=aerol;
}

void Avion::setIdAvion(int idAv){
  idAvion=idAv;
}

int Avion::getIdAvion(){
  return idAvion;
}

string Avion::getAerolinea(){
  return aerolinea;
}

#endif