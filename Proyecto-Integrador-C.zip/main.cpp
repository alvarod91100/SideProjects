#include <iostream>
#include <string>
#include <fstream>
#include "Avion.h"
#include "Tiempo.h"
#include "Vuelo.h"
using namespace std;

//Evalua los vuelos con misma hora de salida
void verificarHorarios(Vuelo listaVuelos[], Tiempo listaHorarios[], int cantVuelos){

  
  for (int contVerifica1 = 0; contVerifica1 < cantVuelos; contVerifica1++){
  
    int contVerifica2=0;
  
    if ((listaHorarios[contVerifica1].getHoraSal() == listaHorarios[contVerifica2].getHoraSal()) && (listaHorarios[contVerifica1].getMinutoSal() == listaHorarios[contVerifica2].getMinutoSal()) ){
      
      cout << endl << "Los vuelos " << listaVuelos[contVerifica1].getID() << " y " << listaVuelos[contVerifica2].getID() << " salen a la misma hora." << endl;
    
    }
    contVerifica2++;
  }
}


//Cuenta la cantidad de vuelos en los archivos
int contarVuelos(int &cantVuelos){
  
  string idV, disp;
  
  Tiempo temporal1;
  
  string orig, dest, stat;
  
  cantVuelos=0;
  
  ifstream archVuelos;
  
  archVuelos.open("Vuelo.txt");
  
  while (archVuelos >> idV >> orig >> dest >> disp >> stat){   
  
    cantVuelos++;
  
  }
  
  return cantVuelos;

}


//Muestra cuantos boletos tiene cada uno de los vuelos
void MuestraBoletos(Vuelo listaVuelos[], int cantVuelos){
  
  for (int cont=0; cont < cantVuelos; cont++){
  
    cout<< "El Vuelo " <<  listaVuelos[cont].getOrigen() << "-" <<  listaVuelos[cont].getDestino() << " cuenta con " <<listaVuelos[cont].getCantBoletos() << " Boletos" << endl;
  }
}


//Carga los datos de horas de salida a los objetos Tipo Vuelo del archivo
void DatosHorarios(Tiempo listaHorarios[], int &cantHorarios,Vuelo listaVuelos[]){
  
  string mSal, hSal;
  
  cantHorarios=0;
  
  ifstream archHorarios;
  
  archHorarios.open("Tiempo.txt");
  
  while (archHorarios >> hSal >> mSal){ 
  
    listaHorarios[cantHorarios].setHoraSal(hSal);
  
    listaHorarios[cantHorarios].setMinutoSal(mSal);
  
    cantHorarios++;
  }

  for (int cont= 0; cont < cantHorarios; cont++){
  
    listaVuelos[cont].setHoraSalida(listaHorarios[cont]);
  
  }

  archHorarios.close();
}


//Carga los datos del avion los objetos Tipo Avion desde el archivo
void DatosAvion(Avion listaAviones[], int &cantAviones, Vuelo listaVuelos[]){
  
  string aerol;
  
  int idAv;
  
  cantAviones=0;
  
  ifstream archAviones;
  
  archAviones.open("Avion.txt");
  
  while (archAviones >> aerol >> idAv){
  
    listaAviones[cantAviones].setAerolinea(aerol);
  
    listaAviones[cantAviones].setIdAvion(idAv);
  
    cantAviones++;
  
  }

  for (int contA=0; contA < cantAviones; contA++){

    listaVuelos[contA].setAvionVuelo(listaAviones[contA]);

  }

  archAviones.close();

}


//Carga los datos del Vuelo a los objetos Tipo Vuelo desde el archivo
void DatosVuelo(Vuelo listaVuelos[], int &cantVuelos, Tiempo listaHorarios[], Avion listaAviones[]){

  int idV;
  int disp;

  Tiempo temporal1;

  Avion avionTemporal;

  string orig, dest, stat;

  cantVuelos=0;

  ifstream archVuelos;

  archVuelos.open("Vuelo.txt");

  while (archVuelos >> idV >> orig >> dest >> disp >> stat){      

      listaVuelos[cantVuelos].setID(idV);

      listaVuelos[cantVuelos].setOrigen(orig);

      listaVuelos[cantVuelos].setDestino(dest);

      listaVuelos[cantVuelos].setCantBoletos(disp);

      listaVuelos[cantVuelos].setStatus(stat);

      listaVuelos[cantVuelos].setHoraSalida(listaHorarios[cantVuelos]);

      listaVuelos[cantVuelos].setAvionVuelo(listaAviones[cantVuelos]);

      cantVuelos++;      
  }

  archVuelos.close();

}


//Funcion que muestra los vuelos al usuario con cout
void muestraVuelos(Vuelo listaVuelos[], int &cantVuelos, Tiempo listaHorarios[], Avion listaAviones[]){
  
  string idV, disp;
  
  Tiempo temporal1;
  
  Avion avionTemporal;
  
  Vuelo vueloTemporal;

  string orig, dest, stat;

  ifstream archVuelos;
  
  archVuelos.open("Vuelo.txt");

  for (int contV=0; contV < cantVuelos; contV++){

    temporal1= listaVuelos[contV].getHoraSalida();

    avionTemporal= listaVuelos[contV].getAvionVuelo();
    
    listaVuelos[contV].mostrarVuelo();

    cout << "Hora de Salida --> " << temporal1.getHoraSal() << ":" << temporal1.getMinutoSal() << endl;

    cout << "Avion: " << avionTemporal.getAerolinea() << " "<< avionTemporal.getIdAvion() <<endl << endl;


  }

}


//Funcion que inicializa la carga de datos a un nuevo Vuelo y asigna atributos a objetos tipo Tiempo y tipo Avion
void anadirVuelos(Vuelo listaVuelos[], Avion listaAviones[], Tiempo listaHorarios[], int &cantVuelos){

  fstream archVuelosN, archHorariosN, archAvionesN; //permite añadir en vez de sobrescribir

  archVuelosN.open("Vuelo.txt",fstream::in | fstream::out | fstream::app); 

  archHorariosN.open("Tiempo.txt",fstream::in | fstream::out | fstream::app);

  archAvionesN.open("Avion.txt",fstream::in | fstream::out | fstream::app);

  Tiempo horarioTemp;

  Avion avionTemp;

  int idNuevoVuelo, boletosNuevoVuelo;
  
  string hSalidaNuevoVuelo, mSalidaNuevoVuelo;

  string destinoNuevoVuelo, origenNuevoVuelo="Mty", aerolineaNuevoVuelo;
  int idAvionNuevoVuelo;
  

  string statusNuevoVuelo, lineaVuelos, lineaHorarios, lineaAviones;

  char opcionStatus, opcionAerolinea;

  cout << endl<< "Introduce el ID del Vuelo (2-3 numeros): ";

  cin >> idNuevoVuelo;

  listaVuelos[cantVuelos].setID(idNuevoVuelo);

  cout<< "Introduce las siglas del destino del vuelo: ";

  cin >>destinoNuevoVuelo;

  listaVuelos[cantVuelos].setDestino(destinoNuevoVuelo);

  cout<< "Introduce la cantidad de boletos que serán disponibles: ";

  cin >>boletosNuevoVuelo;

  listaVuelos[cantVuelos].setCantBoletos(boletosNuevoVuelo);
  

  cout<< "Introduce el status del vuelo: a) A_Tiempo  b) Con_Retraso   ";

  cin >>opcionStatus;

  switch(opcionStatus){

    case 'a':{
      statusNuevoVuelo="A_Tiempo";
      break;
    }

    case 'b':{
      statusNuevoVuelo="Con_Retraso";
      break;
    }
  }

  listaVuelos[cantVuelos].setStatus(statusNuevoVuelo);

  cout<< "Introduce la hora de salida: ";

  cin >> hSalidaNuevoVuelo;

  listaHorarios[cantVuelos].setHoraSal(hSalidaNuevoVuelo);
  
  cout<< "Introduce el minuto de salida: " ;

  cin >> mSalidaNuevoVuelo;

  listaHorarios[cantVuelos].setMinutoSal(mSalidaNuevoVuelo);

  listaVuelos[cantVuelos].setHoraSalida(listaHorarios[cantVuelos]);

  cout<< "Introduce La Aerolinea del Avión: a)Viva  b)Interjet  c)Mexicana  d) Volaris  e) aeroMexico" << endl;

  cin >> opcionAerolinea;

  switch(opcionAerolinea){

    case 'a':{
      aerolineaNuevoVuelo="Viva";
      break;
    }

    case 'b':{
      aerolineaNuevoVuelo="Interjet";
      break;
    }

    case 'c':{
      aerolineaNuevoVuelo="Mexicana";
      break;
    }

    case 'd':{
      aerolineaNuevoVuelo="Volaris";
      break;
    }

    case 'e':{
      aerolineaNuevoVuelo="aeroMexico";
    }
  }

  listaAviones[cantVuelos].setAerolinea(aerolineaNuevoVuelo);


  cout<< "Introduce el id del Avion (3 numeros)" ;

  cin >> idAvionNuevoVuelo;

  listaAviones[cantVuelos].setIdAvion(idAvionNuevoVuelo);

  listaVuelos[cantVuelos].setAvionVuelo(listaAviones[cantVuelos]);

  lineaVuelos= to_string(idNuevoVuelo) + " " + origenNuevoVuelo + " " + destinoNuevoVuelo + " " + to_string(boletosNuevoVuelo) + " " +statusNuevoVuelo;

  lineaHorarios= hSalidaNuevoVuelo + " " + mSalidaNuevoVuelo;

  lineaAviones= aerolineaNuevoVuelo + " " + to_string(idAvionNuevoVuelo);

  cout << endl << endl ;

  cout << "Se ha agregado el vuelo al registro de Vuelos" << endl << endl;


  archVuelosN << endl << lineaVuelos;
  archHorariosN << endl << lineaHorarios;
  archAvionesN << endl<< lineaAviones;

  archVuelosN.close();
  archHorariosN.close();
  archAvionesN.close();

}


//Muestra los aviones en lista, con un cout
void mostrarAviones(Avion listaAviones[], int cantVuelos){

  for (int contA = 0; contA < cantVuelos; contA++){

    cout <<  listaAviones[contA].getAerolinea() << " avion " <<  listaAviones[contA].getIdAvion() << endl;
  }
}


//funcion principal del programa
int main() {
  Vuelo listaVuelos[1000];

  Tiempo listaHorarios[1000];

  Avion listaAviones[1000];

  int cantVuelos=0, cantHorarios=0, cantAviones=0;

  char eleccion;

  contarVuelos(cantVuelos);

  DatosVuelo(listaVuelos,cantVuelos, listaHorarios, listaAviones);

  DatosAvion(listaAviones, cantAviones, listaVuelos);

  DatosHorarios(listaHorarios, cantHorarios, listaVuelos);

  cout << "Bienvenido al programa de registro y administración de Vuelos"<< endl;

  cout << "Vuelos en registro: " << cantVuelos;
  
  do { //Crea el ciclo para el menú
    cout << endl<< "a) Mostrar vuelos" << endl;

    cout << "b) Añdir un vuelo al registro" << endl;

    cout << "c) Consultar aviones registrados" << endl;

    cout << "d) Consultar Boletos Disponibles"<< endl;

    cout << "e) Verificar Horarios de Salida"<< endl;

    cout << "f) Terminar" << endl;

    cin >> eleccion;

    //Da lugar a las opciones y lo que ejecuta cada una
    switch(eleccion){ 

      case 'a':{
          cout << endl<<"Los vuelos registrados son: " << endl;
          DatosHorarios(listaHorarios, cantHorarios, listaVuelos);
          DatosAvion(listaAviones, cantAviones, listaVuelos);
          DatosVuelo(listaVuelos, cantVuelos, listaHorarios, listaAviones);
          muestraVuelos(listaVuelos,cantVuelos, listaHorarios, listaAviones);
          break;
      }

      case 'b':{
       anadirVuelos(listaVuelos,listaAviones, listaHorarios, cantVuelos);
       cantVuelos++;
       break;
      }

      case 'c': {
        cout << "Los aviones registrados son: " << endl;
        mostrarAviones(listaAviones, cantAviones);
        break;
      }

      case 'd':{
        DatosVuelo(listaVuelos,cantVuelos, listaHorarios, listaAviones);
        contarVuelos(cantVuelos);
        MuestraBoletos(listaVuelos,cantVuelos);
        break;
      }
        
      case 'e':{
        verificarHorarios(listaVuelos, listaHorarios,cantVuelos);
        break;
      }
        break;

    }
  
  }while (eleccion != 'f');
  
  cout << endl << "Has salido del programa" << endl << "Vuelos en registro: " << cantVuelos << endl;

 
  return 0;
}

