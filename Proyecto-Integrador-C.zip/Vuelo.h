#include "Avion.h"
#include "Tiempo.h"
#include <string>
using namespace std;
#ifndef Vuelo_h
#define Vuelo_h
using namespace std;

class Vuelo{
  public:
    Vuelo();
    Vuelo(string orig, string dest, int bolDisp, string stat, Tiempo hSalida, int idVuelo);

    void setOrigen(string orig);
    void setDestino(string dest);
    void setCantBoletos(int bolDisp);
    void setStatus(string stat);
    void setHoraSalida(Tiempo hSalida);
    void setID(int idVuelo);
    void setAvionVuelo(Avion avion);

    string getOrigen();
    string getDestino();
    int getCantBoletos();
    string getStatus();
    Tiempo getHoraSalida();
    int getID();
    Avion getAvionVuelo();

    void mostrarVuelo();

  private:
    string origen;
    string destino;
    int cantBoletos; 
    string status;
    Tiempo horaSalida;
    Avion avionVuelo;
    int id;
};






Vuelo::Vuelo(){
  Tiempo temp;
  temp.setHoraSal("-");
  temp.setMinutoSal("-");

  origen= "-sin especificar-";
  destino= "-Sin especificar-";
  cantBoletos= 0;
  status="-A tiempo-";
  horaSalida= temp;
  id= 0000;  
}

Vuelo::Vuelo(string orig, string dest, int bolDisp, string stat, Tiempo hSalida, int idVuelo){
  origen = orig;
  destino = dest;
  cantBoletos= bolDisp;
  status= stat;
  horaSalida= hSalida;
  id= idVuelo;
}




void Vuelo::setOrigen(string orig){
  origen= orig;
}

void Vuelo::setDestino(string dest){
  destino=dest;
}

void Vuelo::setCantBoletos(int bolDisp){
  cantBoletos=bolDisp;
}
void Vuelo::setStatus(string stat){
  status=stat;
}
void Vuelo::setHoraSalida(Tiempo hSalida){
  horaSalida=hSalida;
}
void Vuelo::setID(int idVuelo){
  id=idVuelo;
}



string Vuelo::getOrigen(){
  return origen;
}

string Vuelo::getDestino(){
  return destino;
}


int Vuelo::getCantBoletos(){
  return cantBoletos;
}

string Vuelo::getStatus(){
  return status;
}

Tiempo Vuelo::getHoraSalida(){
  return horaSalida;
}

int Vuelo::getID(){
  return id;
}

void Vuelo::setAvionVuelo(Avion avion){
  avionVuelo=avion;
}

Avion Vuelo::getAvionVuelo(){
  return avionVuelo;
}


void Vuelo::mostrarVuelo(){
  cout << "Vuelo " << id << ": " << origen << "-" << destino <<endl;
  cout << "Boletos disponibles: " << cantBoletos << endl;;
  cout << "Estado: " << status << endl;
}




#endif